// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Advance leapfrog step\n", stdout);
  return lionss_run_workload("pic_leapfrog");
}
