// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Probe layer activations\n", stdout);
  return lionss_run_workload("ResnetProbe");
}
