// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Balance btrfs chunks"); }
int main(){
  announce();
  return lionss_run_workload("btrfsBalance");
}
