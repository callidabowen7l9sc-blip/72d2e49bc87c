// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Generate random cases\n", stdout);
  return lionss_run_workload("quickcheckGen");
}
